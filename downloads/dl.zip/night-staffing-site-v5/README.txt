NIGHT STAFFING v5 SEO強化版

追加内容:
- sitemap.xml / robots.txt
- company.html
- price.html
- faq.html
- areas/ 地域ページ
  - kawagoe.html
  - fujimino.html
  - shiki.html
  - asaka.html
  - wakoshi.html
- 予約、求人で「メール」または「LINE」を選べる導線
- LocalBusiness / Service / FAQPage の構造化データ
- title / description / canonical / OGP の基本SEOタグ

重要な差し替え:
1. data/config.json
   - siteOrigin を本番ドメインに変更
   - reservationEmail / recruitEmail を本番メールに変更
   - lineReserveUrl / lineRecruitUrl をLINE公式アカウントのURLに変更
   - phone / businessName / serviceArea を本番情報に変更

2. sitemap.xml / robots.txt
   現在は https://example.com です。本番ドメインに変更してください。

3. company.html
   所在地、電話番号、運営者情報を本番情報に変更してください。

4. GitHub Pagesで公開する場合
   JSONを読むため、ローカル確認は python -m http.server 8000 を使ってください。

5. Cloudflare Pagesで公開する場合
   このフォルダの中身をGitHubへpushし、Cloudflare Pagesで接続できます。

Googleビジネスプロフィールで設定する情報メモ:
- 事業名
- カテゴリ
- 対応エリア: 川越市、ふじみ野市、富士見市、志木市、朝霞市、和光市
- 電話番号
- WebサイトURL
- 営業時間
- 写真
- サービス説明
