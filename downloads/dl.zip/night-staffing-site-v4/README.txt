NIGHT STAFFING v4

変更点:
- 予約ページを reserve.html に分離しました。
- 求人応募ページを recruit.html に分離しました。
- トップページには概要、キャスト一覧、各詳細ページへの導線だけを残しています。
- 予約ページには「予約から施術・稼働までの流れ」を細かく記載しています。
- 求人応募ページには「求める人材、主な業務内容、給与形態、勤務条件、応募の流れ」を記載しています。
- 予約・求人はボタンを押すとメールアプリが開き、メール本文フォーマットが自動入力されます。

確認方法:
JSONを読み込むため、index.html を直接開くと環境によって動かない場合があります。
このフォルダで以下を実行してください。

python -m http.server 8000

その後、ブラウザで以下を開いてください。
http://localhost:8000

メール宛先の変更:
data/config.json を編集してください。
- reservationEmail
- recruitEmail
- reservationSubject
- recruitSubject

メール本文フォーマットの変更:
- assets/js/reserve.js
- assets/js/recruit.js
- assets/js/cast-detail.js

キャスト写真の追加:
data/casts.json の images 配列に画像パスを追加してください。
